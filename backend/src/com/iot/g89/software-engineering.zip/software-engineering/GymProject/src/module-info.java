module GymProject {
	requires javacsv;
	requires org.junit.jupiter.api;
}