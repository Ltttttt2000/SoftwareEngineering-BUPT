package com.iot.g89;

public class Video {
	String videoId;
	String videoType;
	String detial;
	int price;
	Instructor author;
	Client specificClient;
	
    public Video(String videoId) {
    	
    }

	 String getVideoId() {
		return videoId;
		 
	 }
	 
	 String getVideoType(){
		return videoType;
		 
	 }

	 String getDetial() {
		return detial;
	
	 }
	 
	 int getPrice() {
		return price;
		 
	 }
	 
	 Instructor getAuthor() {
		return author;
		 
	 }
	 
	 Client getSpecificClient() {
		return specificClient;
		 
	 }

	 void setVideoType(String videoType) {
		 
	 }
	 
	 void setDetial(String detial) { 
		 
	 }
	 
	 void setPrice(String price) {
		 
	 }
	 
	 void setAuthor(Instructor author) {
		 
	 }
	 
	 void setSpecificClient(Client specificClient) {
		 
	 }
	 
	 void playVideo() {
		 
	 }

}
